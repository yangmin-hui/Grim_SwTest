﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++에서 생성한 포함 파일입니다.
// GardenDialog.rc에서 사용되고 있습니다.
//
#define IDM_ABOUTBOX                    0x0010
#define IDS_ABOUTBOX                    101
#define IDD_ABOUTBOX                    102
#define IDD_GARDENDLG_DIALOG            103
#define IDD_GARDENDIALOG_DIALOG         103
#define IDR_MAINFRAME                   128
#define IDC_EDIT_RADIUS                 1001
#define IDC_EDIT_PENWIDTH               1002
#define IDC_BTN_INIT                    1003
#define IDC_BTN_RANDOM                  1004
#define IDC_STC_PT0                     1005
#define IDC_STC_PT1                     1006
#define IDC_STC_PT2                     1007

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
